//
//  Weapon.h
//  s24Project3
//
//  Created by Cameron Maiden on 5/22/24.
//

#ifndef Weapon_h
#define Weapon_h

#include "GameObject.h"

class Weapon : public GameObject
{
public:
    
private:
    
};

#endif /* Weapon_h */
