//
//  Scroll.hpp
//  s24Project3
//
//  Created by Cameron Maiden on 5/22/24.
//

#ifndef Scroll_hpp
#define Scroll_hpp

#include "GameObject.h"

class Scroll : public GameObject
{
public:
    
private:
    
};

#endif /* Scroll_hpp */
